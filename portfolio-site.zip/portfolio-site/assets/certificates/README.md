# Certificates folder

Drop your certificate / report PDFs here using these exact filenames so the
links on the site work immediately:

- crop-residue-certificate.pdf
- supply-chain-project-report.pdf
- seismic-source-parameters-report.pdf
- seismic-calculator-project.pdf
- sedimentology-fieldwork-report.pdf
- iymc-2024-certificate.pdf
- jee-main-scorecard.pdf
- iat-scorecard.pdf

If you'd rather host a certificate externally (Google Drive, etc.) instead of
uploading the PDF here, just open `index.html`, find the matching `href`, and
replace it with your external link — e.g.

```html
<a class="log__cert" href="https://drive.google.com/your-link" target="_blank" rel="noopener">📄 View certificate</a>
```

Keep `target="_blank" rel="noopener"` so it opens in a new tab safely.

Tip for Google Drive: open the file → Share → "Anyone with the link" → copy
the link → change `/view?usp=sharing` at the end to `/preview` if you want it
to open inline instead of downloading.
